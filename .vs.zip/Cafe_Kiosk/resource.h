﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// CafeKiosk.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_CafeKioskTYPE               130
#define ID_WINDOW_MANAGER               131
#define IDD_DIALOG1                     310
#define IDD_Menu                        310
#define IDD_DIALOG2                     312
#define IDD_Coffee                      312
#define IDD_DIALOG3                     313
#define IDD_TEA                         313
#define IDD_DIALOG4                     314
#define IDD_SMOOTHIE                    314
#define IDD_DIALOG5                     315
#define IDD_DESSERT                     315
#define IDD_DIALOG6                     316
#define IDD_OPTION                      316
#define IDD_DIALOG9                     317
#define IDD_DIALOG8                     319
#define IDD_MAIN                        319
#define IDD_ORDER1                      320
#define IDD_ORDER                       320
#define IDI_ICON1                       322
#define IDI_ICON2                       329
#define IDI_ICON3                       330
#define IDI_ICON4                       331
#define IDI_ICON5                       332
#define IDI_ICON6                       333
#define IDI_ICON7                       334
#define IDI_ICON8                       335
#define IDI_ICON9                       336
#define IDI_ICON10                      337
#define IDI_ICON11                      338
#define IDC_TAB2                        1042
#define IDC_TAB_TYPE                    1042
#define IDC_LIST2                       1046
#define IDC_LIST_DESSERT                1046
#define IDC_LIST7                       1051
#define IDC_LIST_ORDER                  1051
#define IDC_EDIT3                       1054
#define IDC_EDIT_TOTAL                  1054
#define IDC_BUTTON14                    1055
#define IDC_BUTTON_PAY                  1055
#define IDC_BUTTON17                    1062
#define IDC_BUTTON_ALLDEL               1062
#define IDC_BUTTON18                    1063
#define IDC_BUTTON19                    1064
#define IDC_EDIT1                       1066
#define IDC_EDIT_PRODUCT                1066
#define IDC_CHECK2                      1069
#define IDC_CHECK_OPTION1               1069
#define IDC_RADIO2                      1070
#define IDC_RADIO_OPTION1               1070
#define IDC_RADIO3                      1071
#define IDC_RADIO_OPTION2               1071
#define IDC_BUTTON1                     1072
#define IDC_BUTTON_OPBACK               1072
#define IDC_BUTTON_SELDEL               1073
#define IDC_RADIO4                      1074
#define IDC_LIST_COFFEE                 1074
#define IDC_RADIO_OPTION3               1074
#define IDC_LIST_TEA                    1075
#define IDC_LIST_SMOOTHIE               1076
#define IDC_EDIT2                       1077
#define IDC_EDIT_OPTION1                1077
#define IDC_EDIT4                       1081
#define IDC_EDIT_OPTION2                1081
#define IDC_CHECK3                      1082
#define IDC_CHECK_OPTION2               1082
#define IDC_CHECK4                      1083
#define IDC_CHECK_OPTION3               1083
#define IDC_BUTTON2                     1084
#define IDC_BUTTON_OPDONE               1084

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        339
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1078
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
