﻿// CTea.cpp: 구현 파일
//

#include "pch.h"
#include "Cafe_Kiosk.h"
#include "CTea.h"
#include "afxdialogex.h"


// CTea 대화 상자

IMPLEMENT_DYNAMIC(CTea, CDialogEx)

CTea::CTea(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TEA, pParent)
{

}

CTea::~CTea()
{
}

void CTea::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTea, CDialogEx)
END_MESSAGE_MAP()


// CTea 메시지 처리기


BOOL CTea::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	// 이미지 리스트 생성 및 초기화
	CString m_Name[LENGTH] = { _T("석류에이드"), _T("레몬에이드"), _T("블루레몬에이드"), _T("말차에이드") , _T("청포도에이드") };
	CString m_Payment[LENGTH] = { _T("3000원"), _T("3500원"), _T("3000원"), _T("4000원") , _T("3500원") };

	m_imgTeaList.Create(32, 32, ILC_COLOR32, 0, 0);
	m_imgTeaList.Add(AfxGetApp()->LoadIcon(IDI_ICON7));
	m_imgTeaList.Add(AfxGetApp()->LoadIcon(IDI_ICON8));
	m_imgTeaList.Add(AfxGetApp()->LoadIcon(IDI_ICON9));
	m_imgTeaList.Add(AfxGetApp()->LoadIcon(IDI_ICON10));
	m_imgTeaList.Add(AfxGetApp()->LoadIcon(IDI_ICON11));
	// 여기에 ICON 추가

	// 이미지 리스트와 리스트 연결
	m_listTea.SetImageList(&m_imgTeaList, LVSIL_NORMAL);

	// 아이템 추가
	for (int i = 0; i < LENGTH; i++) {
		m_listTea.InsertItem(i, m_Name[i] + "\n" + m_Payment[i], i);
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
